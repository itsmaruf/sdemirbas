$(".menu-toggler.btn").click(function () {
  $(".menu-items.p-5").toggleClass("active");
});
